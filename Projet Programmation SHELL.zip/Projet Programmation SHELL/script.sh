#!/bin/bash

INPUT=/tmp/menu.sh.$$
OUTPUT=/tmp/output.sh.$$
choix=$(tempfile 2>/dev/null)


trap "rm $OUTPUT; rm $INPUT; rm choix; exit" SIGHUP SIGINT SIGTERM

###Creation de fonctions pour gerer les affichage des 
function menu() {
	dialog --clear --help-button --backtitle "Projet de Programmation Shell" --title "  M E N U " --menu "Vous pouvez utiliserles touches up et down,\nla première lettre de votre choix \nou bien les chiffres correspondants à votre choix,pour defiler." 20 70 5 Calculatrice "Pour lancer une calculatrice" Installation "Pour installer differents serveurs" Terminal "Lancer un terminal sur le navigateur" VOD "Regarder des videos en demande" Quitter "Quitter l'interface"  2>"${INPUT}"
	bout=$?
	menuitem=$(<"${INPUT}")
	case $bout in
		0)	case $menuitem in
				Calculatrice) calcul;;
				Installation) installer;;
				Terminal) terminal;;
				VOD) menuvideo;;
				Quitter) quitter;;
			esac
		;;
		1) quitter;; 
		2) aide ;;
	esac		
}


function ecran_sortie() {
	local h=${1-10}     # height default 10
	local w=${2-41} 	# width default 41
	local t=${3-Output} #  title
	dialog --backtitle "Projet de Programmation Shell" --title "${t}" --clear --msgbox "$(<$OUTPUT)" ${h} ${w}
}

function quitter() {
	echo "        A bientôt!!!" >$OUTPUT
	ecran_sortie 6 30 "Q U I T T E R"
	break
}

function terminal(){
	nohup service gateone start
	nohup firefox https://localhost:443 & 
	rm nohup.out
}

function menuvideo(){
	dialog --backtitle "Projet de Programmation Shell" --title "Menu VOD" --radiolist "Veuillez choisir votre rapport " 20 50 3  1 "NBA All-Star Game 2016" off 2 "Maalaw Pape Diouf" off 2>$choix
	bout=$?
	local choice=$(cat $choix)
	if  [ $bout -eq 0 ] ; then
			case $choice in
				1) nohup firefox sites/video0.html &
				   rm nohup.out	
					;;
				2) nohup firefox sites/video1.html &
				   rm nohup.out	
					;;
			esac
	fi
}

function aide(){
	echo "\nBONJOUR!!! \nCeci est le projet de programmation SHELL qui offre les fonctionnalités suivantes:\n1) La fonctionnalité Calulatrice code en java.
		\n2)La fonctionnalité INSTALLATION qui lorsque vous disposez d'une connexion Internet,permettre installer des serveurs disponibles sur le menu.
		\n3)La fonctionnalité TERMINAL qui permet d'exécuter un terminal sur le navigateur.
		\n4)La fonctionnalité VOD qui permet de visionner des vidéos series disponibles sur le navigateur. 
		\n-----------------------------------------------------------
		 \nLes membres du groupes sont:
		\n* Jean Alphonse Emmanuel CISSE
		\n* Aboubakrine Makhtar DIOP
		\n* El Hadj Ibrahima NDOYE
		\n* El Hadj Aboubacar Ibrahima THIAM" >$OUTPUT
	ecran_sortie 25 70 "A I D E"
}
function installAsterisk(){
     nohup apt-get install build-essential libxml2-dev libncurses5-dev linux-headers-`uname -r` libsqlite3-dev libssl-dev &
     mkdir /usr/src/asterisk 
    cd /usr/src/asterisk 
    nohup wget http://downloads.asterisk.org/pub/telephony/asterisk/asterisk-11-current.tar.gz 
    nohup tar -xvzf asterisk-11-current.tar.gz > /tmp/test
    rm /tmp/test 
    cd asterisk-11.4.0                       
    nohup ./configure     
   nohup make menuselect
   make & 
   make install & 
   make samples &
   make config &
} 

function installer() {
	dialog --backtitle "Projet de Programmation Shell" --title "Menu d'installation de serveurs" --radiolist "Choisir le serveur à installer" 20 50 5  1 "Apache" on 2 "Asterisk" off 3 "DHCP" off 4 "DNS" off 5 "LDAP" off 2>$choix
	bout=$?
	local choice=$(cat $choix)
	if  [ $bout -eq 0 ] ; then
		ping -q -c 2 www.google.com > /dev/null 2>&1
		if [[ $? -eq 0 ]]; then		
			case $choice in
				1) installApache;;
				2) installAsterisk;;
				3) installDHCP;;
				4) installDNS;;
				5)installLDAP;;
			esac
		else
			echo "Veuillez verifier votre connexion." >$OUTPUT
			ecran_sortie 6 30 "Erreur connexion!!!"
		fi
	fi	
	}

function calcul() {
	java -jar Calculatrice.jar &
}

function installApache(){
	nohup apt-get install apache2 
	rm nohup.out
	
}
function installAsterisk(){
	echo "Asterisk" >$OUTPUT
	ecran_sortie 6 30 "Test"
}
function  installDHCP(){
	nohup apt-get install dhcp3-server
	rm nohup.out

}
function  installDNS(){
	nohup apt-get install bind9 dnsutils bind9-doc
	rm nohup.out
}
function installLDAP(){
 	nohup apt-get install  slapd ldap ldap-utils
 	rm nohup.out
}
#MAIN
if [[ $(id -u) -eq 0 ]]; then
	while true
	do
		menu
	done
	clear
	[ -f $OUTPUT ] && rm $OUTPUT
	[ -f $INPUT ] && rm $INPUT
	[ -f PASSWORD ] && rm $PASSWORD
	[ -f choix ] && rm $choix
else
	echo "Ce script doit etre exécute en tant que root."
	echo "Merci de vous connecter en tant que root."
fi
