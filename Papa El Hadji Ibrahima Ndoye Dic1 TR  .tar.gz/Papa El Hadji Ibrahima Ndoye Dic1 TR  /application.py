#! /usr/bin/python
# -*- coding:utf-8 -*-
from flask import Flask
from flask import render_template
from flask import request
from dimensionnement import *
app = Flask(__name__)
#####################################################




def  erlangB(A,N):
    a=0
    for i in range(N+1):
        a+=puissance(A,i)/factoriel(i)
    An=puissance(A,N)
    Nfact=factoriel(N)
    r=An/Nfact
    pb=r/a
    return pb

def nbCircuits(A, a, pb, c):
    i = 1
    j = 0
    for j in range(c):
        if A[j][0]==pb:
            for i in range(53):
                print(str(i))
                if A[j][i]==a or (A[j][i]<a and A[j][i+1]>a) :
                    print(str(i))
                    break
                #i = i+1
        #j = j+1
    return i

def nbCircuitsC(A, a, pb, c):
    i = 1
    j = 0
    for j in range(c):
        if A[j][0]==pb:
            for i in range(51):
                print(str(i))
                if A[j][i]==a or (A[j][i]<a and A[j][i+1]>a) :
                    print(str(i))
                    break
                #i = i+1
        #j = j+1
    return i

def traficB(A,N,pb,c):
    i = 0
    while(i<=(c-1)) and (A[i][0]!=pb):
        i=i+1
    return A[i][N]

def erlangC(A,N):
    a=0
    for k in range(N):
        a+=puissance(A,k)/factoriel(k)
    a+=puissance(A,N)/(factoriel(N)*(1-A/N))
    p0=1/a
    A=puissance(A,N)/(factoriel(N)*(1-A/N))
    r=A*p0
    return r

def fileAttente(A,N):
    if((A/N)<1):
        #calcul de Po
        p0=0
        for i in range(N+1):
            p0+=(puissance(A,i))/(factoriel(i))
        p0+=(puissance(A,N+1))/(factoriel(N)*(N-A))
        p0=1/p0
        #calcul de la longueur moyenne de la file d'attente
        nu=factoriel(N)*N*puissance((1-A/N),2)
        nu=(puissance(A,N+1)*p0)/nu
        return nu





######################################################
@app.route('/')
def depart():
	return render_template('index.html')

@app.route('/erlangb', methods=['GET', 'POST'])
def erlangb():
	if request.method == 'POST':
		global toff,ndc,tdb
		a=request.form['toff']
		n=request.form['ndc']
		tdb=request.form['tdb']
		if tdb=='':
			a=float(request.form['toff'])
			n=int(request.form['ndc'])
			if a<0 or n<0:
				return '''<b><center><font color="red" size="6">Mauvaise valeur</font></center></b>'''
			Pb1 = puissance(a,n)/factoriel(n)
			Pb2 = 0
			for k in range(n+1):
				Pb2 = Pb2+puissance(a,k)/factoriel(k)
			Pb = float(Pb1/Pb2)
			Ae = float(a*(1-Pb))
			Pb=Pb*100
			return render_template('resultaterlangb.html',toff=a,ndc=n,tdb=Pb,ecoule=Ae)
		if a=='':
			proba = float(request.form['tdb'])
			nbcircuit = int(request.form['ndc'])
			A = list()
			for k in range(5):
				A.append([])
				for l in range(53):
					A[k].append([])
			for k in range(5):
				for l in range(53):
					A[k][l] = 0
			fich = open("erlangB.txt", "r")
			for i in range(5):
				for j in range(53):
					A[i][j] = float(fich.readline())
			traffic = traficB(A, nbcircuit, proba, 5)
			resultat = str(round(traffic, 2))
			return render_template('resultaterlangb.html',toff=resultat,ndc=nbcircuit,tdb=proba,ecoule="inconnu")
		if n=='':
			proba = float(request.form['tdb'])
			traffic = int(request.form['toff'])
			A = list()
			for k in range(5):
				A.append([])
				for l in range(53):
					A[k].append([])
			for k in range(5):
				for l in range(53):
					A[k][l] = 0
			fich = open("erlangB.txt", "r")
			for i in range(5):
				for j in range(53):
					A[i][j] = float(fich.readline())
			nbCir = nbCircuits(A, traffic, proba, 5)
			resultat = str(nbCir)
			return render_template('resultaterlangb.html',toff=traffic,ndc=resultat,tdb=proba,ecoule="inconnu")
	return render_template('erlangb.html')


@app.route('/erlangc', methods=['GET', 'POST'])
def erlangc():
	if request.method == 'POST':
		global toff,ndc,tdb
		a=request.form['a']
		n=request.form['n']
		prob=request.form['prob']
		if prob=='' and n>a:
			a=float(request.form['a'])
			n=int(request.form['n'])
			if a<0 or n<0 or a<n:
				return '''<b><center><font color="red" size="6">Mauvaise valeur</font></center></b>'''
			o1=puissance(a,n)/factoriel(n)
			o2=n/(n-a)
			o3=o1*o2
			B2 = 0
			for k in range(n):
				B2 = B2+puissance(a,k)/factoriel(k)
			B = o3+B2
			B=o3/B2
			return render_template('resultaterlangc.html',toff=a,ndc=n,tdb=B)
		if a=='' and n>a:
			proba = float(request.form['prob'])
			nbcircuit = int(request.form['n'])
			A = list()
			for k in range(9):
				A.append([])
				for l in range(51):
					A[k].append([])
			for k in range(5):
				for l in range(51):
					A[k][l] = 0
			fich = open("erlangC.txt", "r")
			for i in range(5):
				for j in range(51):
					A[i][j] = float(fich.readline())
			traffic = traficB(A, nbcircuit, proba, 9)
			resultat = str(round(traffic, 3))
			return render_template('resultaterlangc.html',toff=resultat,ndc=nbcircuit,tdb=proba)
		if n=='':
			proba = float(request.form['prob'])
			traffic = int(request.form['a'])
			A = list()
			for k in range(9):
				A.append([])
				for l in range(51):
					A[k].append([])
			for k in range(9):
				for l in range(51):
					A[k][l] = 0
			fich = open("erlangC.txt", "r")
			for i in range(9):
				for j in range(51):
					A[i][j] = float(fich.readline())
			nbCir = nbCircuitsC(A, traffic, proba, 9)
			resultat = str(nbCir)
			return render_template('resultaterlangc.html',toff=traffic,ndc=resultat,tdb=proba)
	return render_template('erlangc.html')


@app.route('/dimensionnement', methods=['GET', 'POST'])
def dimensionnement():
	if request.method == 'POST':
		global lamda,mu,nb
		lamda=int(request.form['lamda'])
		mu=int(request.form['mu'])
		nb=int(request.form['serveurs'])
		if lamda < nb*mu:
			nu=calcul_nu(lamda,nb,mu)
			tf=calcul_t(lamda,mu,nb)
			tf1=float(tf*60)
			tf2=float(tf*3600)
			n=calcul_n(lamda,mu,nb)
			theta=float(lamda)/float(mu)
			rho=int(nb-theta)
			return render_template("resultatdimensionnement.html",nu=nu,tf1=tf1,n=n,rho=rho)
		elif lamda >= nb*mu:
			return '''<b><center><font color="red" size="6">Veillez à ce que λ soit inferieur à μs</font></center></b>'''
	return render_template('dimensionnement.html')








if __name__ == '__main__':
	app.run(debug="true",host="0.0.0.0")

