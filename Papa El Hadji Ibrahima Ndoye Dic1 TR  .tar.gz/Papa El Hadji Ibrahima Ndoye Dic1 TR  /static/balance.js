function changement()
        {
            y=document.getElementById('zonetexte');
            y.style.borderColor = 'red';

        }
        function doIt()
        {
            var i,j=0;
            y=document.getElementById('zonetexte').value;
            if(y<2)
            {
                divi=document.getElementById('tab');
                divi.innerHTML="</br> <font color='red' size='2'>Erreur de saisie veillez entrer une bonne valeur</font>";
            }
            if(y>=2 && y<20)
            {
                bout=document.getElementById('bouton');
                rien=document.getElementById('rien');
                formu=document.getElementById('formulaire');
                divi=document.getElementById('tab');
                var children = formu.childNodes;
                divi.innerHTML="</br> Saisissez les éléments de la matrice";
                divi.innerHTML+="</br></br>";
                //y.parentNode.removeChild(y);
                for(var i=0;i<y;i++)
                {
                    for(var j=0;j<y;j++)
                    {
                        divi.innerHTML+="<input type='text' size='4' name="+i+i+">";
                    }
                divi.innerHTML+="<br/>";
                }
                formu.removeChild(formu[0]);
                //rien.replaceChild(bout,rien.firstChild); valide 
                divi.innerHTML+="</br></br><input type='submit' value='Inverser la matrice'>";

                //open_infos();
            }
        }


        function open_infos()
                        {
                                width = 500;
                                height = 300;
                                if(window.innerWidth)
                                {
                                        var left = (window.innerWidth-width)/2;
                                        var top = (window.innerHeight-height)/2;
                                }
                                else
                                {
                                        var left = (document.body.clientWidth-width)/2;
                                        var top = (document.body.clientHeight-height)/2;
                                }
                                window.open('index.html','nom_de_ma_popup','menubar=no, scrollbars=no, top='+top+', left='+left+', width='+width+', height='+height+'');
                        }